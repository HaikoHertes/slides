﻿# Konfiguration vor dem Ändern
Get-DscLocalConfigurationManager

Configuration MyLCMConfig
{
    Param([string]$ComputerName)
    node ($ComputerName)
    {
        LocalConfigurationManager 
        {
            ConfigurationMode = "ApplyAndAutoCorrect"   # Autokorrektur 
                                                        # nur überwachen: "ApplyAndMonitor"
            ConfigurationModeFrequencyMins = 15         # Wie oft soll die Configuration angewendet werden?
                                                        # Kleiner geht nicht, 30min ist default
            RebootNodeIfNeeded = $True
            RefreshMode = "Pull"                        # "Push" ist default
            RefreshFrequencyMins = 30                   # Download der Config vom Server alle x min
                                                        # 30min ist default, nur für Pull-Mode

        }
     }
}

MyLCMConfig -OutputPath "C:\myDSC\LCM" -ComputerName localhost

Set-DscLocalConfigurationManager -Path "C:\myDSC\LCM"

# Konfiguration nach dem Ändern
Get-DscLocalConfigurationManager