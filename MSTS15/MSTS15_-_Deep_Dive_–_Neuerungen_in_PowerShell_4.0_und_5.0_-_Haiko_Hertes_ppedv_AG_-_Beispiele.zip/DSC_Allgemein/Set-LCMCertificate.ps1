﻿Get-DscLocalConfigurationManager

Configuration MyLCMConfig
{
    Param([string]$ComputerName)
    node ($ComputerName)
    {
        LocalConfigurationManager 
        {
            CertificateID = "1F6AA235CF795D1E50902FA68E31C344CCB76EEC"
        }
     }
}

MyLCMConfig -OutputPath "C:\myDSC\LCMCert" -ComputerName "SRV3"

Set-DscLocalConfigurationManager -Path "C:\myDSC\LCMCert"

Get-DscLocalConfigurationManager