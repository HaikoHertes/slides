﻿Configuration ClusterDemo 
{ 
    param([Parameter(Mandatory=$true)]  
          [ValidateNotNullorEmpty()]  
          [PsCredential]$domainAdminCred) 

    Import-DscResource –ModuleName "PSDesiredStateConfiguration"
    Import-DscResource -Name xCluster, xWaitForCluster

    
    Node $AllNodes.Where{$_.Role -eq "ErsterClusterKnoten" }.NodeName 
    { 

        File Hosts
        {
            SourcePath = "\\srv1\Share\hosts"
            DestinationPath = "C:\Windows\System32\drivers\etc"
            Type = "File"
            Checksum = "modifiedDate"
            Force = $True
        }
        
        WindowsFeature FailoverFeature 
        { 
            Ensure = "Present" 
            Name   = "Failover-clustering" 
        } 
 
        WindowsFeature RSATClusteringPowerShell 
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-PowerShell"    
 
            DependsOn = "[WindowsFeature]FailoverFeature" 
        }
        
        WindowsFeature RSATClusteringMgmt  
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-Mgmt"    
 
            DependsOn = "[WindowsFeature]FailoverFeature" 
        } 
 
        WindowsFeature RSATClusteringCmdInterface 
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-CmdInterface" 
 
            DependsOn = "[WindowsFeature]RSATClusteringPowerShell" 
        }
        
        Service MSiSCSI
        {
            Name = "MSiSCSI"
            StartupType = "Automatic"
            State = "Running"
        } 
        
        Script iScsiPortal
        {
            TestScript = {(Get-IscsiTargetPortal | Where TargetPortalAddress -eq "192.168.200.1" | Measure-Object).Count -ge 1}
            GetScript  = {@{ Result = (Get-IscsiTargetPortal | Where TargetPortalAddress -eq "192.168.200.1") } }
            SetScript  = {New-IscsiTargetPortal -TargetPortalAddress "192.168.200.1"}
            DependsOn  = "[Service]MSiSCSI"
        }
        
        Script iScsiDisk
	    { 
	        TestScript = { (Get-IscsiTarget | Where NodeAddress -eq "iqn.1991-05.com.microsoft:srv1-iscsi-target1-target").IsConnected -eq $True } 
	        GetScript  = { @{ Result = Get-IscsiTarget -NodeAddress "iqn.1991-05.com.microsoft:srv1-iscsi-target1-target" } } 
	        SetScript  = { Get-IscsiTarget | Connect-IscsiTarget -IsPersistent $True } 
            DependsOn  = "[Script]iScsiPortal"
	    } 
         
        xCluster ensureCreated 
        { 
            Name = $Node.ClusterName 
            StaticIPAddress = $Node.ClusterIPAddress 
            DomainAdministratorCredential = $domainAdminCred 
            DependsOn = “[WindowsFeature]RSATClusteringCmdInterface”,"[Script]iScsiDisk","[File]Hosts"
       }
       
       Script WitnessDisk
        {
            TestScript = { ((Get-ClusterQuorum -Cluster MSTSCluster).QuorumType -eq "Majority") -and ((Get-ClusterQuorum -Cluster MSTSCluster).QuorumResource -like "Cluster Disk*") } 
	        GetScript  = { @{ Result = (Get-ClusterQuorum -Cluster MSTSCluster).QuorumResource } } 
	        SetScript  = { Do{Start-Sleep -s 1}until((Get-ClusterResource | Where-Object ResourceType -eq "Physical Disk" | Measure-Object).Count -ge 1); Set-ClusterQuorum -Cluster MSTSCluster -NodeAndDiskMajority (Get-ClusterResource | Where-Object ResourceType -eq "Physical Disk") } 
            DependsOn  = '[xCluster]ensureCreated'
        }  
         
    } 
 
    Node $AllNodes.Where{ $_.Role -eq "WeitererClusterKnoten" }.NodeName 
    {          
        
        File Hosts
        {
            SourcePath = "\\srv1\Share\hosts"
            DestinationPath = "C:\Windows\System32\drivers\etc"
            Type = "File"
            Checksum = "modifiedDate"
            Force = $True
        }
        
        WindowsFeature FailoverFeature 
        { 
            Ensure = "Present" 
            Name      = "Failover-clustering" 
        } 
 
        WindowsFeature RSATClusteringPowerShell 
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-PowerShell"    
 
            DependsOn = "[WindowsFeature]FailoverFeature" 
        }
        
        WindowsFeature RSATClusteringMgmt  
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-Mgmt"    
 
            DependsOn = "[WindowsFeature]FailoverFeature" 
        }
        
 
        WindowsFeature RSATClusteringCmdInterface 
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-CmdInterface" 
 
            DependsOn = "[WindowsFeature]RSATClusteringPowerShell" 
        }
        
        Service MSiSCSI
        {
            Name = "MSiSCSI"
            StartupType = "Automatic"
            State = "Running"
        } 
                
        Script iScsiPortal
        {
            TestScript = {(Get-IscsiTargetPortal | Where TargetPortalAddress -eq "192.168.200.1" | Measure-Object).Count -ge 1}
            GetScript  = {@{ Result = (Get-IscsiTargetPortal | Where TargetPortalAddress -eq "192.168.200.1") } }
            SetScript  = {New-IscsiTargetPortal -TargetPortalAddress "192.168.200.1"}
            DependsOn  = "[Service]MSiSCSI"
        }
        
        Script iScsiDisk
	    { 
	        TestScript = { (Get-IscsiTarget | Where NodeAddress -eq "iqn.1991-05.com.microsoft:srv1-iscsi-target1-target").IsConnected -eq $True } 
	        GetScript  = { @{ Result = Get-IscsiTarget -NodeAddress "iqn.1991-05.com.microsoft:srv1-iscsi-target1-target" } } 
	        SetScript  = { Get-IscsiTarget | Connect-IscsiTarget -IsPersistent $True } 
            DependsOn  = "[Script]iScsiPortal"
	    }
         
        xWaitForCluster waitForCluster 
        { 
            Name = $Node.ClusterName 
            RetryIntervalSec = 10 
            RetryCount = 60 
 
            DependsOn = “[WindowsFeature]RSATClusteringCmdInterface”,"[Script]iScsiDisk"   
        } 
 
        xCluster joinCluster 
        { 
            Name = $Node.ClusterName
            StaticIPAddress = $Node.ClusterIPAddress 
            DomainAdministratorCredential = $domainAdminCred
 
            DependsOn = "[xWaitForCluster]waitForCluster" 
        }

        
           
         
    }

    Node $AllNodes.Where{ $_.Role -eq "Verwaltungsserver" }.NodeName
    {
    
        WindowsFeature RSATClusteringMgmtSrv1  
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-Mgmt"            
        }

        WindowsFeature RSATClusteringPowerShellSrv1 
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-PowerShell"    
         
        }

        WindowsFeature RSATClusteringCmdInterfaceSrv1
        { 
            Ensure = "Present" 
            Name   = "RSAT-Clustering-CmdInterface" 
 
            DependsOn = "[WindowsFeature]RSATClusteringPowerShellSrv1" 
        }

        File ClusterMMC
        {
            SourcePath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Administrative Tools\Failover Cluster Manager.lnk"
            DestinationPath = "C:\Users\Public\Desktop"
            Type = "File"
            DependsOn = "[WindowsFeature]RSATClusteringMgmtSrv1"
            
        }
        


        
    } 
} 
 
 
$ConfigData = @{ 
    AllNodes = @( 
 
        @{ 
            NodeName= "*" 
 
            CertificateFile = "C:\Keys\Dsc_Cluster_Demo.cer"
            Thumbprint = "1F6AA235CF795D1E50902FA68E31C344CCB76EEC"
            ClusterName = "MSTSCluster"
            ClusterIPAddress = "192.168.200.10/24"
        },
        
         # SRV1
        @{
            NodeName= "SRV1"
            Role = "Verwaltungsserver"
            PSDscAllowDomainUser = $True
        } 
 
         # SRV2 
        @{ 
            NodeName= "SRV2"
            Role = "ErsterClusterKnoten"
            PSDscAllowDomainUser = $True
            
         }, 
 
         # SRV3
         @{ 
            NodeName= "SRV3"
            Role = "WeitererClusterKnoten" 
            PSDscAllowDomainUser = $True
         } 
    ); 
} 
 
Write-Warning "Konfiguration der Server vor dem Benutzen der DSC:"
"SRV1","SRV2","SRV3" | ForEach-Object {Get-WindowsFeature -ComputerName $_ -Name "*Cluster*"}

# Administrator-Kennung abfragen
$domainAdminCred = Get-Credential -UserName "HERTES\Administrator" -Message "Enter password for Administrator" 

# MOF-Dateien erzeugen
ClusterDemo -ConfigurationData $ConfigData -domainAdminCred $domainAdminCred -OutputPath C:\myDSC\Cluster\

# Konfiguration umsetzen
Start-DscConfiguration "C:\myDSC\Cluster\" -Wait -Verbose -Force

Write-Warning "Konfiguration der Server nach dem Benutzen der DSC:"

Get-Cluster -Name MSTSCluster | Get-ClusterNode
Get-Cluster -Name MSTSCluster | Get-ClusterQuorum

"SRV1","SRV2","SRV3" | ForEach-Object {Get-WindowsFeature -ComputerName $_ -Name "*Cluster*"}

Start-Process "cluadmin"

