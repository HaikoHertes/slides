﻿Param(

    [switch]$CheckPatches = $False,
    [switch]$CheckSoftware = $True,
    $ReferenzSystem = "SRV1",
    $KopieSysteme = "SRV2"
)

cls

Write-Host "Prüfe die Maschine(n) $KopieSysteme gegen den Server $ReferenzSystem..."

# Was ist an Software auf dem Quellsystem?
$ReferenzPackages  = Invoke-Command -ScriptBlock {Get-Package} -ComputerName $ReferenzSystem

If($CheckSoftware)
{
    # Was von den Packages ist "echte" Software aus dem Chocolatey-Repository?
    $ReferenzSoftware = $ReferenzPackages | Where-Object ProviderName -eq "Chocolatey"

    # Iteration über alle Computer auf der Liste der zu prüfenden Geräte
    ForEach($Computer in $KopieSysteme)
    {
        # Was ist an Software auf dem aktuell geprüften Zielsystem?
        $ZielSoftware = Invoke-Command -ScriptBlock {Get-Package -WarningAction SilentlyContinue | Where-Object ProviderName -eq "Chocolatey"} -ComputerName $Computer
        
        # Worin unterscheiden sich Referenz- und Zielsystem?
        $Unterschiede = Compare-Object -ReferenceObject $ReferenzSoftware -DifferenceObject $ZielSoftware -Property Name,Version -IncludeEqual -PassThru

        # Software, die auf dem Zielsystem fehlt
        Write-Host "`nSoftware, die auf dem Zielsystem fehlt:" -ForegroundColor Red
        $Zuwenig = $Unterschiede | Where-Object SideIndicator -eq "<="
        $Zuwenig | Format-Table Name,Version
        Invoke-Command -ScriptBlock {$Args | ForEach-Object {Install-Package -Name $_.Name -RequiredVersion $_.Version -Source Chocolatey -WhatIf}} -ArgumentList $Zuwenig -ComputerName $Computer
        

        # Software, die auf dem Zielsystem zu viel ist
        Write-Host "`nSoftware, die auf dem Zielsystem zu viel ist:" -ForegroundColor Cyan
        $Zuviel = $Unterschiede | Where-Object SideIndicator -eq "=>"
        $Zuviel | Format-Table Name,Version
        Invoke-Command -ScriptBlock {$Args | ForEach-Object {Uninstall-Package -Name $_.Name -ProviderName Chocolatey -WhatIf -ErrorAction SilentlyContinue -WarningAction SilentlyContinue}} -ArgumentList $Zuviel -ComputerName $Computer

        # Software, die auf beiden Systemen installiert ist
        Write-Host "`nSoftware, die beide Systeme haben:" -ForegroundColor Green
        $Beide = $Unterschiede | Where-Object SideIndicator -eq "=="
        $Beide | Format-Table Name,Version

    }
}

<#
If($CheckPatches)
{
    $AlleUpdates = @{}
    $ReferenzUpdates = $ReferenzPackages | Where-Object ProviderName -eq "msu"
    $AlleUpdateBeschreibungen = $ReferenzUpdates
    Write-Host "Folgende Updates sind auf dem Referenz-System installiert:" -ForegroundColor Yellow
    forEach($EinUpdate in $AlleUpdateBeschreibungen)
    {
        if($EinUpdate.CanonicalId -like "* KB*")
        {
            #KB-Nummer NICHT in Klammern
            $KBNr = ($EinUpdate.CanonicalId.Substring($EinUpdate.CanonicalId.indexof("KB"))).Substring(0,$EinUpdate.CanonicalId.Substring($EinUpdate.CanonicalId.indexof("KB")).IndexOf(" "))
        
        }
        else
        {
            #KB-Nummer IN Klammern
            $KBNr = $EinUpdate.CanonicalId.Substring($EinUpdate.CanonicalId.IndexOf("(KB")+1,$EinUpdate.CanonicalId.IndexOf(")")-$EinUpdate.CanonicalId.IndexOf("(KB")-1)
        }
        #Write-Host "$KBNr"
        #$EinUpdate | Format-Table @{n="KBNummer";e={$KBNr}},@{n="Beschreibung";e={$_.CanonicalId}} -HideTableHeaders
        $ErrorActionPreference = "SilentlyContinue"
        $AlleUpdates.Add($KBNr,$EinUpdate.CanonicalId)
        $ErrorActionPreference = "Continue"
    }
    $AlleUpdates | Format-Table -AutoSize -HideTableHeaders
}
#>
