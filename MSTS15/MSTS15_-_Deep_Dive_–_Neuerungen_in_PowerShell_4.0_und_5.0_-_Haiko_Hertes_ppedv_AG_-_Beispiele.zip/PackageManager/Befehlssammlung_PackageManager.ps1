﻿Get-PackageSource | ft Name,Location
<#
PS C:\Users\Administrator> Get-PackageSource | ft Name,Location

Name      Location                                                  
----      --------                                                  
PSGallery https://go.microsoft.com/fwlink/?LinkID=397631&clcid=0x409
#>

Get-PackageProvider
<#
PS C:\Users\Administrator> Get-PackageProvider

Name                     Version          DynamicOptions                                                                                                                                                    
----                     -------          --------------                                                                                                                                                    
Programs                 10.0.10514.0     {IncludeWindowsInstaller, IncludeSystemComponent}                                                                                                                 
msi                      10.0.10514.0     {AdditionalArguments}                                                                                                                                             
msu                      10.0.10514.0     {}                                                                                                                                                                
NuGet                    2.8.5.127        {Destination, SkipDependencies, ContinueOnFailure, ExcludeVersion...}                                                                                             
PSModule                 1.0.0.0          {PackageManagementProvider, Location, InstallUpdate, InstallationPolicy...}                                                                                       
#>



#Register-PackageSource -Name chocolatey -Provider PSModule -Trusted -Location http://chocolatey.org/api/v2/ -Verbose
#Get-Item 'C:\Chocolatey' | Remove-Item
#Unregister-PackageSource chocolatey
#Set-PackageSource -Name chocolatey -Trusted
Get-PackageProvider Chocolatey -ForceBootstrap

Get-PackageSource
<#
PS C:\Users\Administrator> Get-PackageSource

Name                             ProviderName     IsTrusted  IsRegistered IsValidated  Location                                                                                                             
----                             ------------     ---------  ------------ -----------  --------                                                                                                             
PSGallery                        PSModule         False      True         False        https://www.powershellgallery.com/api/v2/                                                                            
chocolatey                       PSModule         True       True         False        http://chocolatey.org/api/v2/                                                                                        
#>

Find-Package | Out-GridView -Title "Übersicht aller Pakete" -PassThru | Install-Package -Force
# --> Auswahl aller verfügbaren Pakete

#Get-Package | Where-Object Name -Like "*irfan*"

Find-Package dosbox | Install-Package
