﻿# Ohne die Force-Schalter würden mehrfach Gegenfragen gestellt werden
Get-PackageProvider Chocolatey -Force
Find-Package vlc -Force | Install-Package -Force -ForceBootstrap
Find-Package -ProviderName Chocolatey | Out-GridView



Find-Package DotNet3.5 -Force | Install-Package -Force -ForceBootstrap