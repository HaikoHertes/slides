﻿Configuration WebserverDemo
{
    Import-DscResource –ModuleName "PSDesiredStateConfiguration"

    Node ("SRV2","SRV3")
    {
        Registry NoServerManagerAutostart
        {
            Ensure = "Present"
            Key = "HKLM:\SOFTWARE\Microsoft\ServerManager"
            ValueName = "DoNotOpenServerManagerAtLogon"
            ValueData = "1"
        }
       
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }

        File WebDirectory
        {
            Ensure = "Present"
            SourcePath = "\\srv1\Share\Webserver"
            Recurse = $true
            DestinationPath = "c:\inetpub\wwwroot"
            Type = "Directory"
            DependsOn = "[WindowsFeature]IIS"        # Ohne IIS haben die Daten keinen Zweck
        }

        Service WWWDienst
        {
            Name = "w3svc"
            StartUpType = "Automatic"
            DependsOn = "[WindowsFeature]IIS"        # Dienst kann nur auf automatischem Start stehen, wenn vorhanden
        }

        Group Webadmins
        {
            Ensure = "Present"
            Groupname = "Webadministratoren"
        }

    }

}

# MOF-Dateien erzeugen
WebserverDemo -OutputPath C:\myDSC\Webserver\

# Konfiguration umsetzen
Start-DscConfiguration "C:\myDSC\Webserver\" -Wait -Verbose -Force

Start-Process "C:\Program Files\Internet Explorer\iexplore.exe" -ArgumentList "http://SRV2.hertes.demo/"
Start-Process "C:\Program Files\Internet Explorer\iexplore.exe" -ArgumentList "http://SRV3.hertes.demo/"