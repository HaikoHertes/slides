﻿# Auslesen der CPU-Informationen via WMI
$CPU = Get-WmiObject Win32_Processor -ComputerName localhost
# Auslesen der RAM-Informationen via WMI
$RAM = Get-WmiObject Win32_OperatingSystem -ComputerName localhost
# Auslesen der HDD-Informationen via WMI
$Disk = Get-WmiObject Win32_LogicalDisk -ComputerName localhost | Where-Object DeviceId -Like C*

$CPU
$RAM.FreePhysicalMemory
$RAM.TotalVisibleMemorySize
$Disk