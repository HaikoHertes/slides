﻿Param(
    [Parameter(Mandatory=$True)]
    [string[]]$TargetComp
)

# Auslesen der CPU-Informationen via WMI
$CPU = Get-WmiObject Win32_Processor -ComputerName $TargetComp
# Auslesen der RAM-Informationen via WMI
$RAM = Get-WmiObject Win32_OperatingSystem -ComputerName $TargetComp
# Auslesen der HDD-Informationen via WMI
$Disk = Get-WmiObject Win32_LogicalDisk -ComputerName $TargetComp | Where-Object DeviceId -Like C*

$CPU
$RAM.FreePhysicalMemory
$RAM.TotalVisibleMemorySize
$Disk